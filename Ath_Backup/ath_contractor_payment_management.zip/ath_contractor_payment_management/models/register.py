from odoo import models, fields, api, _
from odoo.exceptions import ValidationError


class Register(models.Model):
    _name = 'register'
    _description = 'Payment Register'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _rec_name = 'customer_name'

    notes = fields.Html(string="Note")
    contractor_id = fields.Many2one('contractor', string="Contractor Name")
    customer_name = fields.Char(string="Customer Name")
    site_ids = fields.Many2one(
        'site',
        string='Site Name',
        store=True,
        domain="[('contractor_id', '=', contractor_id)]"
    )
    date = fields.Date(string="Date", default=fields.Date.today)
    currency_id = fields.Many2one(
        'res.currency', string="Currency",
        default=lambda self: self.env.company.currency_id.id
    )
    amount = fields.Monetary(string="Amount", currency_field='currency_id', tracking=True)
    remarks = fields.Char(string="Remarks")

    @api.constrains('amount')
    def _check_amount_non_zero(self):
        for record in self:
            if record.amount == 0:
                raise ValidationError("Amount cannot be zero.")