from odoo import models, fields


class Site(models.Model):
    _name = 'site'
    _description = 'Site'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string="Customer Name")
    contractor_id = fields.Many2one('contractor', string="Contractor Name")
    site_name = fields.Char(string='Site Name')
    site_incharge = fields.Char(string='Site Incharge')
    street = fields.Char("Street")
    street2 = fields.Char("Street2")
    city = fields.Char("City")
    zip = fields.Char("ZIP")
    state_id = fields.Many2one('res.country.state', string="State")
    country_id = fields.Many2one('res.country', string="Country")

    def name_get(self):
        result = []
        for rec in self:
            name = rec.site_name or rec.name or "Unnamed Site"
            result.append((rec.id, name))
        return result