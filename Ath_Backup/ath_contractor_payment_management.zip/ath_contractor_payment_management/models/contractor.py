from odoo import models, fields


class Contractor(models.Model):
    _name = 'contractor'
    _description = 'Contractor'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Contractor Name')
    note = fields.Html(string='Note')
    street = fields.Char("Street")
    street2 = fields.Char("Street2")
    city = fields.Char("City")
    zip = fields.Char("ZIP")
    state_id = fields.Many2one('res.country.state', string="State")
    country_id = fields.Many2one('res.country', string="Country")