from odoo import models, fields, api


class SaleOrderAdvancePaymentWizard(models.TransientModel):
    _name = 'sale.order.advance.payment.wizard'
    _description = 'Sale Order Advance Payment Wizard'

    advance_id = fields.Many2one('sale.order.advance', string="Advance", required=True)
    payment_date = fields.Date(string="Payment Date", required=True,default=fields.Date.today)
    payment_amount = fields.Float(string="Amount", required=True)

    @api.model
    def default_get(self, fields_list):
        print("Default_get:::::::::::::::::::::::::::::")
        res = super(SaleOrderAdvancePaymentWizard, self).default_get(fields_list)

        # Print the incoming context (should include 'default_advance_id')
        print("=====> Default Get Method Triggered")
        print("Context in default_get: ", self._context)

        # Retrieve the sale order advance using active_id from the context
        advance_id = self.env['sale.order.advance'].browse(self._context.get('default_advance_id'))

        # Print the fetched record
        print("Fetched advance_id record: ", advance_id)


        # Check if the advance exists
        if advance_id:

            if advance_id.advance_amount != 0:
                print(f"advance_id found: {advance_id.id}, tax_total_amount: {advance_id.tax_total_amount}")
                res.update({
                    'advance_id': advance_id.id,
                    'payment_amount': advance_id.tax_total_amount - advance_id.advance_amount,  # Dynamically set the payment amount
                })
            else:
                print(f"advance_id found: {advance_id.id}, tax_total_amount: {advance_id.tax_total_amount}")
                res.update({
                    'advance_id': advance_id.id,
                    'payment_amount': advance_id.tax_total_amount,  # Dynamically set the payment amount
                })
        else:
            print("No advance_id record found!")

        print("=====> Default Get Result: ", res)
        return res



    def apply_payment(self):
        """ Update the sale.order.advance with the payment amount and date """
        for record in self:
            # Print to debug and verify values
            print(
                f"Applying payment of {record.payment_amount} on {record.payment_date} for advance {record.advance_id.id}")

            # Update the sale.order.advance with the payment details
            advance = record.advance_id
            advance.write({
                'advance_amount': advance.advance_amount + record.payment_amount,
                'date': record.payment_date,
                'stage': 'conform'
            })
            # Optionally, you could add logic to update other fields like the status
            # advance.stage = 'paid' # Example if you want to set a status after payment
        return {'type': 'ir.actions.act_window_close'}
