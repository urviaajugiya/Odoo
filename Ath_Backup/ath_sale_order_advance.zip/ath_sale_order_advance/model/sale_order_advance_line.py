from odoo import models, fields, api

from odoo.exceptions import ValidationError


class SaleOrderAdvanceLine(models.Model):
    _name = 'sale.order.advance.line'
    _description = 'Sale Order Advance Line'

    so_line_id = fields.Many2one('sale.order.line', string="Sale Order Line", required=True)
    so_id = fields.Many2one('sale.order', string="Sale Order", required=True)
    advance_id = fields.Many2one('sale.order.advance', string=" Advance ID ")
    proforma_percentage = fields.Float(string="Proforma Percentage", digits='Percentage')
    product_template_id = fields.Many2one('product.template', string="Product")
    display_name_with_desc = fields.Text(string='Description',compute="_compute_display_name_with_desc", store=True, readonly=False)
    # name = fields.Text(string='Description')
    sequence = fields.Integer(string="Sequence", default=10)

    @api.depends('product_template_id')
    def _compute_display_name_with_desc(self):
        for rec in self:
            if rec.product_template_id:
                name = rec.product_template_id.name or ''
                desc = rec.product_template_id.description_sale or ''
                if desc:
                    rec.display_name_with_desc = f"{name}\n {desc}"
                else:
                    rec.display_name_with_desc = name
            else:
                rec.display_name_with_desc = ''

    # @api.onchange('product_template_id')
    # def _onchange_product_template_id(self):
    #     if self.product_template_id:
    #         lang = self.so_id.partner_id.lang if self.so_id and self.so_id.partner_id else self.env.user.lang
    #         template = self.product_template_id.with_context(lang=lang)
    #         self.name = template.name or ''
    #         if template.description_sale:
    #             self.name += "\n" + template.description_sale

    # product_template_id = fields.Many2one('product.template', string="Product", groups='name.description_sale')
    price_unit = fields.Float(string='Unit Price', readonly=True)
    tax_ids = fields.Many2many('account.tax', string='Taxes', readonly=True)
    # tax_id = fields.Many2many('account.tax', string='Taxes',readonly=True)
    amount = fields.Monetary(string="Amount", currency_field='currency_id', compute='_get_amount', store=True,
                             readonly=True)
    quantity = fields.Float(string="Quantity", digits='Product Unit of Measure', readonly=True)
    uom_id = fields.Many2one('uom.uom', string="Unit of Measure", readonly=True)
    currency_id = fields.Many2one('res.currency', string='Currency', required=True,
                                  default=lambda self: self.env.company.currency_id)
    # hsn_code = fields.Char(string='HSN/SAC Code', related='product_id.product_template_id.l10n_in_hsn_code', store=True, readonly=True)
    hsn_code = fields.Char(string='HSN/SAC Code', related='product_template_id.l10n_in_hsn_code', store=True,
                           readonly=True)
    sale_line_amount = fields.Monetary(string="Sale Line Amount", related='so_line_id.price_subtotal', store=True)

    @api.constrains('proforma_percentage')
    def _check_proforma_percentage_editable(self):
        for line in self:
            print(f"Checking proforma_percentage change for SaleOrderAdvanceLine {line.id}")
            if line.advance_id:
                print(f"Found advance_id: {line.advance_id.id}")
                print(f"Current stage: {line.advance_id.stage}")

            # If the stage is not 'new', raise validation error
            if line.advance_id and line.advance_id.stage != 'new':
                print(f"Validation Error: Cannot modify 'proforma_percentage' in the '{line.advance_id.stage}' stage.")
                raise ValidationError(
                    "The 'Proforma Percentage' can only be modified in the 'New' stage of the Advance."
                )
            else:
                print(f"proforma_percentage can be modified (stage is 'new').")

    @api.constrains('proforma_percentage')
    def _check_proforma_percentage(self):
        errors = []
        for record in self:
            print(f"Checking proforma_percentage for record {record.id} with value {record.proforma_percentage}")

            # Get all related lines for the same advance_id and in 'conform' stage
            advance_lines = self.env['sale.order.advance.line'].search([
                ('advance_id', '!=', record.advance_id.id),
                ('so_line_id', '=', record.so_line_id.id),
                ('product_template_id', '=', record.product_template_id.id),
                # ('proforma_percentage', '>', 0)  # We only care about lines with a positive percentage
                # ('advance_id.stage', '=', 'conform')  # Only include lines related to 'conform' stage

            ])
            if advance_lines:
                print(f"Found {len(advance_lines)} related advance lines for advance_id {record.advance_id.id}")

                # Check if the sum of all percentages exceeds 100%
                total_percentage = sum(line.proforma_percentage for line in advance_lines)
                print(f"Total proforma_percentage across all related lines: {total_percentage}%")

                # if total_percentage + record.proforma_percentage > 100:
                #     print(
                #         f"Error: Total proforma percentage exceeds 100%. Current total: {total_percentage + record.proforma_percentage}%")
                #     valid_value = 100 - total_percentage
                #     raise ValidationError(
                #         # f"The Total Proforma Percentage for {record.product_template_id.name} should not be greater than {valid_value}.")
                #         f"The Total Proforma Percentage should not be greater than {valid_value}.")
                if total_percentage + record.proforma_percentage > 100:
                    current_total = total_percentage + record.proforma_percentage
                    valid_value = 100 - total_percentage
                    error_msg = (
                        f"[{record.product_template_id.name}] Total Proforma Percentage exceeds 100% "
                        f"(Current Total: {current_total}%, Max Allowed: 100%). "
                        f"Allowed additional percentage: {valid_value}%"
                    )
                    errors.append(error_msg)
                elif record.proforma_percentage > 100:
                    raise ValidationError(
                        f"The total proforma percentage for {record.product_template_id.name} should not be greater than 100%.")
        if errors:
            raise ValidationError("\n\n".join(errors))

            # # Additional validation: Check if any of the records in 'conform' stage has 50%
            # if record.proforma_percentage > 50:
            #     print(f"Proforma percentage is {record.proforma_percentage}%, checking for existing 50% entries...")
            #
            #     # Check if there are already 50% records in the same advance
            #     existing_50_percent_lines = self.env['sale.order.advance.line'].search([
            #         ('advance_id', '=', record.advance_id.id),
            #         ('proforma_percentage', '=', 50)
            #     ])
            #     print(f"Found {len(existing_50_percent_lines)} existing lines with 50% proforma percentage")
            #
            #     if existing_50_percent_lines:
            #         print(f"Error: Another record already has 50% proforma percentage.")
            #         raise ValidationError(
            #             "There is already a 50% proforma percentage in this advance. You cannot set another one.")

    @api.depends('price_unit', 'quantity', 'product_template_id', 'proforma_percentage')
    def _get_amount(self):
        print(self, "sef:::::::::::::::::::::::::::::::::::::::::::::")
        for rec in self:
            print(rec, "rec::::::::::::::::::::::::::::::::::::::::::::::::")
            print(rec.price_unit, "rec.price_unit::::::::::::::::::::::::")
            print(rec.quantity, "rec.quantity::::::::::::::::::::::::")
            base = rec.price_unit * rec.quantity
            print(base, "base:::::::::::::::::::::::::::::::::::::::::::::::::::::::::")
            rec.amount = base * (rec.proforma_percentage / 100.0)
            print(rec.amount, "rec.amount::::::::::::::::::::::::::::::::::::::::::::::::")
