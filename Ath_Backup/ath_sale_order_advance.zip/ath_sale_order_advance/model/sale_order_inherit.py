# from importlib.resources import _

from odoo import models, fields, api,_
from odoo.osv import expression

from odoo.exceptions import UserError, ValidationError


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    advance_amount = fields.Monetary(string='Total Advance Amount', compute='_compute_order_advance_amount', store=True)
    tax_totals = fields.Binary(compute='_compute_tax_totals', exportable=False)
    amount_untaxed = fields.Monetary(string="Untaxed Amount", store=True, compute='_compute_amounts', tracking=5)
    amount_tax = fields.Monetary(string="Taxes", store=True, compute='_compute_amounts')
    amount_total = fields.Monetary(string="Total", store=True, compute='_compute_amounts', tracking=4)
    subsidy_amount = fields.Monetary(string="Subsidy Amount", readonly=False)
    # Define the computed field to count the related advances
    advance_count = fields.Float(string="Advances Count", compute="_compute_advance_count")
    currency_id = fields.Many2one('res.currency', related='pricelist_id.currency_id', store=True)

    # @api.depends('sale_order_advance_ids')  # Assuming you have a Many2many or One2many relationship
    @api.depends('sale_order_advance_ids.tax_total_amount')
    def _compute_advance_count(self):
        # for order in self:
        #     order.advance_count = sum(order.sale_order_advance_ids.mapped('tax_total_amount'))
        for order in self:
            valid_advances = order.sale_order_advance_ids.filtered(lambda adv: adv.stage != 'cancel')
            order.advance_count = sum(valid_advances.mapped('tax_total_amount'))


    # def _compute_advance_count(self):
    #     for order in self:
    #         # Print to see the count of advances for each sale order
    #         print(f"Computing advance_count for Sale Order {order.name}")
    #         print(f"Related Advances: {order.sale_order_advance_ids}")
    #
    #         # Count the related advances
    #         order.advance_count = len(order.sale_order_advance_ids)
    #
    #         # Print to verify the computed advance_count
    #         print(f"Computed advance_count for Sale Order {order.name}: {order.advance_count}")

    def action_view_advances(self):
        all_sale_order_advance = self.env['sale.order.advance'].search([('order_id', '=', self.id)])
        print(f'all_sale_order_advance:::{all_sale_order_advance}')

        action_window = {
            'type': 'ir.actions.act_window',
            'name': _('Sale Order Advance'),  # Title of the action
            'res_model': 'sale.order.advance',  # Model name
            'view_id': False,  # Optional: Specific view_id if known
        }

        if len(all_sale_order_advance) <= 1:
            action_window.update({
                "res_id": all_sale_order_advance.id,
                "views": [[False, "form"]],
            })
        else:
            action_window.update({
                "domain": [('id', 'in', all_sale_order_advance.ids)],
                "views": [[False, "list"], [False, "kanban"], [False, "form"]],
            })
        return action_window

    def create_proforma_invoice(self):
        exsisting_new_stage_advance = self.env['sale.order.advance'].search([('order_id', '=',self.id ),('stage', '=','new')])
        if not exsisting_new_stage_advance:
            for order in self:
                if not order.order_line:
                    raise UserError("No order lines to create proforma invoice for.")

                # Total advance amount (you can customize this logic)
                # total_amount = sum(order.order_line.mapped('price_subtotal'))
                # advance_amount = total_amount * 0.5  # Example: 50% advance

                advance = self.env['sale.order.advance'].create({
                    'order_id': order.id,
                    'proforma_date': fields.Date.today(),
                    # 'advance_amount': advance_amount,
                    # 'total_amount': total_amount,
                    'currency_id': order.currency_id.id,
                })

                # Create advance lines
                for line in order.order_line:
                    self.env['sale.order.advance.line'].create({
                        'advance_id': advance.id,
                        'so_id': order.id,
                        'so_line_id': line.id,
                        'tax_ids': line.tax_id,
                        'product_template_id': line.product_template_id.id,  # or derive dynamically
                        'price_unit': line.price_unit,
                        'quantity': line.product_uom_qty,
                        'uom_id': line.product_uom.id,
                        'currency_id': order.currency_id.id,
                    })

            return {
                'type': 'ir.actions.act_window',
                'res_model': 'sale.order.advance',
                'view_mode': 'form',
                'res_id': advance.id,
                'target': 'current',
            }
        else:
            raise ValidationError(_("Proforma Invoice is already create for this SO. in new stage"))

    # def _prepare_invoice(self):
    #     print("Preparing invoice...")
    #     invoice_vals = super(SaleOrder, self)._prepare_invoice()
    #     print("Initial invoice_vals:", invoice_vals)
    #
    #     # Create payments for advance amounts
    #     for advance in self.sale_order_advance_ids:
    #         print(f"Creating payment for advance amount {advance.advance_amount} on invoice {invoice_vals['invoice_origin']}")
    #         payment_vals = {
    #             'payment_type': 'inbound',
    #             'partner_type': 'customer',
    #             'partner_id': self.partner_id.id,
    #             'amount': advance.advance_amount,
    #         }
    #             # 'currency_id': advance.currency_id.id,
    #             # 'payment_date': fields.Date.today(),
    #             # 'communication': f'Payment for Advance on Invoice {invoice_vals["invoice_origin"]}',
    #             # 'invoice_ids': [(4, invoice_vals['invoice_origin'])],
    #         print("Payment values:", payment_vals)
    #         payment = self.env['account.payment'].create(payment_vals)
    #         print("Payment created:", payment)
    #         # Let's find the related invoice object
    #         # Let's find the related invoice object
    #         # Let's find the related invoice object
    #         # Let's find the related invoice object
    #         invoice = self.env['account.move'].search([('invoice_origin', '=', invoice_vals['invoice_origin'])],
    #                                                   limit=1)
    #         if invoice:
    #             invoice.post()
    #             print("Invoice posted successfully!")
    #         else:
    #             print("No related invoice found for this payment.")
    #
    #     print("Invoice preparation complete.")
    #     return invoice_vals

    # old method
    # @api.depends('order_line.price_subtotal', 'order_line.price_tax', 'order_line.price_total','subsidy_amount')
    # def _compute_amounts(self):
    #     """Compute the total amounts of the SO."""
    #     for order in self:
    #         order_lines = order.order_line.filtered(lambda x: not x.display_type)
    #
    #         if order.company_id.tax_calculation_rounding_method == 'round_globally':
    #             tax_results = self.env['account.tax']._compute_taxes([
    #                 line._convert_to_tax_base_line_dict()
    #                 for line in order_lines
    #             ])
    #             totals = tax_results['totals']
    #             amount_untaxed = totals.get(order.currency_id, {}).get('amount_untaxed', 0.0)
    #             amount_tax = totals.get(order.currency_id, {}).get('amount_tax', 0.0)
    #         else:
    #             amount_untaxed = sum(order_lines.mapped('price_subtotal'))
    #             amount_tax = sum(order_lines.mapped('price_tax'))
    #
    #         order.amount_untaxed = amount_untaxed
    #         order.amount_tax = amount_tax
    #         order.amount_total = order.amount_untaxed + order.amount_tax

    @api.depends('order_line.price_subtotal', 'order_line.price_tax', 'order_line.price_total', 'subsidy_amount')
    def _compute_amounts(self):
        AccountTax = self.env['account.tax']
        for order in self:
            order_lines = order.order_line.filtered(lambda x: not x.display_type)
            base_lines = [line._prepare_base_line_for_taxes_computation() for line in order_lines]
            AccountTax._add_tax_details_in_base_lines(base_lines, order.company_id)
            AccountTax._round_base_lines_tax_details(base_lines, order.company_id)
            tax_totals = AccountTax._get_tax_totals_summary(
                base_lines=base_lines,
                currency=order.currency_id or order.company_id.currency_id,
                company=order.company_id,
            )
            print("method calling from _compute_amounts")
            order.amount_untaxed = tax_totals['base_amount_currency']
            order.amount_tax = tax_totals['tax_amount_currency']
            order.amount_total = tax_totals['total_amount_currency']
            # order.amount_total_cc = tax_totals['total_amount']

        for rec in self:
            print(rec,"rec@@@@@@@@@@@@@@@@@@@@@@@@")
            if rec.subsidy_amount:
                print(rec.subsidy_amount,"rec.subsidy_amount!!!!!!!!!!!!!!!!!!!!!!!")
                rec.amount_untaxed -= rec.subsidy_amount
                rec.amount_total -= rec.subsidy_amount
                order.tax_totals['amount_total'] -= order.subsidy_amount
                # formatted_amount_total = '₹{:,.2f}'.format(rec.tax_totals['amount_total'])
                # print(formatted_amount_total, "formatted_amount_total^^^^^^^^^^^^^^^^^^^")
                print(rec.amount_untaxed,"rec.amount_untaxed!!!!!!!!!!!!!!!!!!!")
                print(rec.amount_total,"rec.amount_total!!!!!!!!!!!!!!!!!!!")
                # rec.amont -= rec.subsidy_amount


    @api.depends_context('lang')
    @api.depends('order_line.tax_id', 'order_line.price_unit', 'amount_total', 'amount_untaxed', 'currency_id',
                 'subsidy_amount')
    def _compute_tax_totals(self):
        for order in self:
            order_lines = order.order_line.filtered(lambda x: not x.display_type)
            # order.tax_totals = self.env['account.tax']._prepare_tax_totals(
            #     [x._convert_to_tax_base_line_dict() for x in order_lines],
            #     order.currency_id or order.company_id.currency_id,
            # )
            AccountTax = self.env['account.tax']
            for order in self:
                if not order.company_id:
                    order.tax_totals = False
                    continue
                order_lines = order.order_line.filtered(lambda x: not x.display_type)
                base_lines = [line._prepare_base_line_for_taxes_computation() for line in order_lines]
                AccountTax._add_tax_details_in_base_lines(base_lines, order.company_id)
                AccountTax._round_base_lines_tax_details(base_lines, order.company_id)
                order.tax_totals = AccountTax._get_tax_totals_summary(
                    base_lines=base_lines,
                    currency=order.currency_id or order.company_id.currency_id,
                    company=order.company_id,
                )
                print(order.tax_totals,"order.tax_totals::::::::::::::::::::::::")
            if 'amount_total' in order.tax_totals and order.subsidy_amount:
                print(order.subsidy_amount,"order.subsidy_amount@@@@@@@@@@@@@@@@@@2")
                order.tax_totals['amount_untaxed'] -= order.subsidy_amount
                subtotals = order.tax_totals.get('subtotals')
                print(subtotals,"subtotals%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
                sub_total = order.tax_totals['subtotals']
                print(sub_total,"sub_total@@@@@@@@@@@@@@@@@@@@@@222222222222222222222")
                sub_total[0]['amount'] -= order.subsidy_amount
                print(sub_total[0]['amount'], "sub_total['amount']$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$4")
                sub_total[0]['formatted_amount'] = '₹ {:,.2f}'.format(sub_total[0]['amount'])
                print(sub_total[0]['formatted_amount'],
                      "sub_total['formatted_amount']^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^")
                order.tax_totals['amount_total'] -= order.subsidy_amount
                order.tax_totals['formatted_amount_untaxed'] =  '₹ {:,.2f}'.format(order.tax_totals['amount_untaxed'])
                order.tax_totals['formatted_amount_total'] =  '₹ {:,.2f}'.format(order.tax_totals['amount_total'])
                print(order.tax_totals['amount_total'], "formatted_amount_total^^^^^^^^^^^^^^^^^^^")
                print(order.tax_totals,"order.tax_totals!!!!!!!!!!!!!!")

    # def action_add_advance(self):
    #     return {
    #         'name': 'Add Advance',
    #         'type': 'ir.actions.act_window',
    #         'res_model': 'sale.order.advance.wizard',
    #         'view_mode': 'form',
    #         'target': 'new',
    #
    #
    #
    #     }

    # @api.depends('order_line.price_subtotal', 'order_line.price_tax', 'order_line.price_total','advance_amount')
    # def _compute_amounts(self):
    #     """Compute the total amounts of the SO."""
    #     for order in self:
    #         order_lines = order.order_line.filtered(lambda x: not x.display_type)
    #
    #         if order.company_id.tax_calculation_rounding_method == 'round_globally':
    #             tax_results = self.env['account.tax']._compute_taxes([
    #                 line._convert_to_tax_base_line_dict()
    #                 for line in order_lines
    #             ])
    #             totals = tax_results['totals']
    #             amount_untaxed = totals.get(order.currency_id, {}).get('amount_untaxed', 0.0)
    #             amount_tax = totals.get(order.currency_id, {}).get('amount_tax', 0.0)
    #         else:
    #             amount_untaxed = sum(order_lines.mapped('price_subtotal'))
    #             amount_tax = sum(order_lines.mapped('price_tax'))
    #
    #         order.amount_untaxed = amount_untaxed
    #         order.amount_tax = amount_tax
    #         order.amount_total = order.amount_untaxed + order.amount_tax
    #     for rec in self:
    #         print(rec,"rec@@@@@@@@@@@@@@@@@@@@@@@@")
    #         if rec.advance_amount:
    #             print(rec.advance_amount,"rec.advance_amount!!!!!!!!!!!!!!!!!!!!!!!")
    #             rec.amount_untaxed -= rec.advance_amount
    #             rec.amount_total -= rec.advance_amount
    #             order.tax_totals['amount_total'] -= order.advance_amount
    #             # formatted_amount_total = '₹{:,.2f}'.format(rec.tax_totals['amount_total'])
    #             # print(formatted_amount_total, "formatted_amount_total^^^^^^^^^^^^^^^^^^^")
    #             print(rec.amount_untaxed,"rec.amount_untaxed!!!!!!!!!!!!!!!!!!!")
    #             print(rec.amount_total,"rec.amount_total!!!!!!!!!!!!!!!!!!!")
    #             # rec.amont -= rec.advance_amount
    #
    #
    #
    # @api.depends_context('lang')
    # @api.depends('order_line.tax_id', 'order_line.price_unit', 'amount_total', 'amount_untaxed', 'currency_id','advance_amount')
    # def _compute_tax_totals(self):
    #     print("RTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT")
    #     for order in self:
    #         order_lines = order.order_line.filtered(lambda x: not x.display_type)
    #         order.tax_totals = self.env['account.tax']._prepare_tax_totals(
    #             [x._convert_to_tax_base_line_dict() for x in order_lines],
    #             order.currency_id or order.company_id.currency_id,
    #         )
    #         print(order.advance_amount, "order.advance_amount@@@@@@@@@@@@@@@@@@1")
    #         if 'amount_total' in order.tax_totals and order.advance_amount:
    #             print(order.advance_amount,"order.advance_amount@@@@@@@@@@@@@@@@@@2")
    #             order.tax_totals['amount_untaxed'] -= order.advance_amount
    #             subtotals = order.tax_totals.get('subtotals')
    #             print(subtotals,"subtotals%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
    #             sub_total = order.tax_totals['subtotals']
    #             print(sub_total,"sub_total@@@@@@@@@@@@@@@@@@@@@@222222222222222222222")
    #             sub_total[0]['amount'] -= order.advance_amount
    #             print(sub_total[0]['amount'], "sub_total['amount']$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$4")
    #             sub_total[0]['formatted_amount'] = '₹ {:,.2f}'.format(sub_total[0]['amount'])
    #             print(sub_total[0]['formatted_amount'],
    #                   "sub_total['formatted_amount']^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^")
    #             order.tax_totals['amount_total'] -= order.advance_amount
    #             order.tax_totals['formatted_amount_untaxed'] =  '₹ {:,.2f}'.format(order.tax_totals['amount_untaxed'])
    #             order.tax_totals['formatted_amount_total'] =  '₹ {:,.2f}'.format(order.tax_totals['amount_total'])
    #             print(order.tax_totals['amount_total'], "formatted_amount_total^^^^^^^^^^^^^^^^^^^")
    #             print(order.tax_totals,"order.tax_totals!!!!!!!!!!!!!!")

    sale_order_advance_ids = fields.One2many('sale.order.advance','order_id',string='Sale Order Advance')
    amount_due_advance = fields.Monetary(string='Amount Due',compute='_compute_amount_due_advance')


    @api.depends('advance_amount','amount_total')
    def _compute_amount_due_advance(self):
        for order in self:
            order.amount_due_advance = order.amount_total - order.advance_amount
            print(f"Computed advance amount due for sale order {order.amount_due_advance}: {order.advance_amount}: Totsl Amount {order.amount_total}")





    @api.depends('sale_order_advance_ids.advance_amount')
    def _compute_order_advance_amount(self):
        for order in self:
            order.advance_amount = sum(order.sale_order_advance_ids.mapped('advance_amount'))
            print(f"Computed advance amount for sale order {order.name}: {order.advance_amount}")






