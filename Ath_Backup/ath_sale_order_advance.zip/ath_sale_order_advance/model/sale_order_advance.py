from odoo import _, api, fields, models

from odoo import models, fields, api

from odoo.exceptions import UserError

from odoo.exceptions import ValidationError

from collections import defaultdict

import markupsafe

from odoo import Command, models, fields, api, _
from odoo.exceptions import UserError
from odoo.tools import frozendict, SQL


class SaleOrderAdvance(models.Model):
    _name = 'sale.order.advance'
    _rec_name = 'proforma_invoice_seq'

    proforma_invoice_seq = fields.Char(string='Proforma Invoice Number', readonly=True, required=True, copy=False,default='New')
    order_id = fields.Many2one('sale.order', string='Order', readonly=True)
    date = fields.Date(string="Invoice Date", default=fields.Date.today)
    duo_date = fields.Date(string="Due Date", default=fields.Date.today)
    proforma_date = fields.Date(string="Proforma Date", default=fields.Date.today)
    advance_amount = fields.Monetary(string='Recieved Amount', readonly=True)
    tax_total_amount = fields.Monetary(string='Total Amount', compute='_get_tax_total_amount', store=True,
                                       readonly=True)
    due_amount = fields.Monetary(string='Due Amount', readonly=True,compute='_compute_due_amount')
    # total_amount = fields.Monetary(string='Total Amount',store=True)
    currency_id = fields.Many2one('res.currency', string='Currency', default=lambda self: self.env.ref('base.INR').id,
                                  readonly=True)
    flag_for_clear_advance_in_invoice = fields.Boolean(string='Advance clearing in invoice ', readonly=True)
    stage = fields.Selection(
        [('new', 'Draft'), ('conform', 'Confirm'), ('cancel', 'Cancel'), ('partial', 'Partial'), ('paid', 'Paid')],
        default="new", string='Stage')
    tax_id = fields.Many2many('account.tax', string='Taxes', readonly=True)
    proforma_note = fields.Html(string='Proforma note')
    advance_line_ids = fields.One2many('sale.order.advance.line', 'advance_id', string='Advance Lines')
    # Add the JSON field with compute method
    additional_data = fields.Json(string='Additional Data', compute='_compute_additional_data', store=True)
    display_invoice_amount_total_words = fields.Char(
        compute="_compute_amount_words"
    )
    cgst_amount = fields.Monetary(string="CGST", compute="_compute_tax_amounts", store=True, readonly=True)
    sgst_amount = fields.Monetary(string="SGST", compute="_compute_tax_amounts", store=True, readonly=True)
    igst_amount = fields.Monetary(string="IGST", compute="_compute_tax_amounts", store=True, readonly=True)
    untaxed_amount  = fields.Monetary(string="Untaxed Amount", compute="_compute_untaxed_amount", store=True, readonly=True)

    # sale_line_amount = fields.Monetary(
    #     string="Sale Line Amount",
    #     compute='_compute_total_line_amount',
    #     store=True,
    #     currency_field='currency_id'
    # )
    #
    # @api.depends('so_line_id.price_subtotal')
    # def _compute_total_line_amount(self):
    #     for record in self:
    #         record.sale_line_amount = record.so_line_id.price_subtotal or 0.0


    @api.depends('advance_line_ids', 'advance_line_ids.amount')
    def _compute_untaxed_amount(self):
        for rec in self:
            total_untaxed = sum(line.amount for line in rec.advance_line_ids)
            rec.untaxed_amount = total_untaxed

    @api.depends('additional_data')
    def _compute_tax_amounts(self):
        for rec in self:
            data = rec.additional_data or {}
            rec.cgst_amount = data.get('cgst', 0.0)
            rec.sgst_amount = data.get('sgst', 0.0)
            rec.igst_amount = data.get('igst', 0.0)

    @api.depends('tax_total_amount')
    def _compute_amount_words(self):
        for rec in self:
            if rec.tax_total_amount and rec.currency_id:
                rec.display_invoice_amount_total_words = rec.currency_id.amount_to_text(rec.tax_total_amount)
            else:
                rec.display_invoice_amount_total_words = ''


    @api.depends('tax_total_amount', 'advance_amount')
    def _compute_due_amount(self):
        for record in self:
            record.due_amount = (record.tax_total_amount or 0.0) - (record.advance_amount or 0.0)

    def action_print_pdf(self):
        return self.env.ref('ath_sale_order_advance.action_proforma_invoice').report_action(self)

    @api.depends('advance_amount', 'tax_total_amount', 'advance_line_ids', 'advance_line_ids.proforma_percentage')
    def _compute_additional_data(self):
        for rec in self:
            # Initialize totals
            total = 0
            untaxtotal = 0
            cgst = 0
            sgst = 0
            igst = 0

            # Loop over each advance line and calculate subtotal and taxes
            for line in rec.advance_line_ids:
                print(f"Processing line: {line}, amount: {line.amount}")
                base = line.amount
                print(f"Base amount: {base}")

                # Add to untaxtotal (total amount before tax)
                untaxtotal += base

                # Calculate taxes using the tax_ids of the line
                if line.tax_ids:
                    taxes = line.tax_ids.compute_all(base, currency=rec.currency_id, product=line.product_template_id)
                    print(f"Taxes calculated: {taxes}")

                    # Loop over the taxes to separate CGST, SGST, and IGST
                    for tax in taxes['taxes']:
                        if 'cgst' in tax['name'].lower():
                            cgst += tax['amount']
                        elif 'sgst' in tax['name'].lower():
                            sgst += tax['amount']
                        elif 'igst' in tax['name'].lower():
                            igst += tax['amount']

                # Add the base amount (including tax) to the total
                total += base
                print(f"Total after adding base: {total}")

            # Apply rounding to two decimal places for all monetary values
            untaxtotal = round(untaxtotal, 2)
            total = round(total, 2)
            cgst = round(cgst, 2)
            sgst = round(sgst, 2)
            igst = round(igst, 2)

            # Store the computed data in the additional_data field
            additional_info = {
                'subtotal': untaxtotal,  # Total before tax
                'total_amount_with_tax': total + cgst + sgst + igst,  # Total after tax
                'cgst': cgst,
                'sgst': sgst,
                'igst': igst,
                'total_tax_amount': cgst + sgst + igst,  # Sum of all taxes
                'advance_amount': rec.advance_amount,
                'is_advance_greater_than_tax': rec.advance_amount > (cgst + sgst + igst),
                'note': 'Advance payment status'
            }

            print(f"Additional data computed: {additional_info}")
            rec.additional_data = additional_info

    # @api.depends('advance_amount', 'tax_total_amount', 'advance_line_ids')
    # def _compute_additional_data(self):
    #     for rec in self:
    #         total = 0
    #         cgst = 0
    #         sgst = 0
    #         igst = 0
    #         untaxtotal = 0
    #         for line in rec.advance_line_ids:
    #             print(line, "line::::::::2222222222222::::::::::::::")
    #             base = line.amount
    #             print(base, "base::::::::::::::::22222222222222222::::::::::::::::::::::::::::::::::::::::")
    #             # taxes = line.tax_ids.compute_all(base, currency=rec.currency_id)
    #             # print(taxes, "taxes:::::::::::::::::::")
    #             untaxtotal += base
    #             print(total, "total::::::22222222222222222::::::::::::::::")
    #         subtotal = untaxtotal
    #         print(subtotal, "rec.tax_total_amount::::::::::::222222222222222222222::::::::::::::::::::")
    #
    #         # Loop over each advance line and calculate subtotal and taxes
    #         for line in rec.advance_line_ids:
    #             print(f"Processing line: {line}, amount: {line.amount}")
    #             base = line.amount
    #             print(f"Base amount: {base}")
    #
    #             # Calculate taxes using the tax_ids of the line
    #             if line.tax_ids:
    #                 taxes = line.tax_ids.compute_all(base, currency=rec.currency_id, product=line.product_id)
    #                 print(f"Taxes calculated: {taxes}")
    #
    #                 # Loop over the taxes to separate CGST, SGST, and IGST
    #                 for tax in taxes['taxes']:
    #                     if 'cgst' in tax['name'].lower():
    #                         cgst += tax['amount']
    #                     elif 'sgst' in tax['name'].lower():
    #                         sgst += tax['amount']
    #                     elif 'igst' in tax['name'].lower():
    #                         igst += tax['amount']
    #
    #             total += base
    #             print(f"Total after adding base: {total}")
    #
    #         # Store the subtotal and taxes in the additional_data field
    #         additional_info = {
    #             'subtotal': untaxtotal,
    #             'total_amount_with_tax': total,
    #             'cgst': cgst,
    #             'sgst': sgst,
    #             'igst': igst,
    #             'total_tax_amount': cgst + sgst + igst,
    #             'advance_amount': rec.advance_amount,
    #             'is_advance_greater_than_tax': rec.advance_amount > (cgst + sgst + igst),
    #             'note': 'Advance payment status'
    #         }
    #
    #         print(f"Additional data computed: {additional_info}")
    #         rec.additional_data = additional_info

    # @api.model
    # def create(self, vals):
    #     print("Entering the create method")
    #     if vals.get('proforma_invoice_seq', 'New') == 'New':
    #         seq = self.env['ir.sequence'].next_by_code('sale.order.advance') or '/'
    #         print(f"Generated sequence: {seq}")
    #         vals['proforma_invoice_seq'] = seq
    #     return super(SaleOrderAdvance, self).create(vals)

    # @api.depends('advance_amount', 'tax_total_amount')
    # def _compute_additional_data(self):
    #     for rec in self:
    #         total = 0
    #         for line in rec.advance_line_ids:
    #             print(line, "line::::::::2222222222222::::::::::::::")
    #             base = line.amount
    #             print(base, "base::::::::::::::::22222222222222222::::::::::::::::::::::::::::::::::::::::")
    #             # taxes = line.tax_ids.compute_all(base, currency=rec.currency_id)
    #             # print(taxes, "taxes:::::::::::::::::::")
    #             total += base
    #             print(total, "total::::::22222222222222222::::::::::::::::")
    #         subtotal = total
    #         print(subtotal, "rec.tax_total_amount::::::::::::222222222222222222222::::::::::::::::::::")
    #
    #         # Calculate the dictionary based on your business logic
    #         additional_info = {
    #             'subtotal': subtotal,
    #             # 'cgst': subtotal,
    #             # 'subtotal': subtotal,
    #
    #             # 'amount': record.advance_amount,
    #             # 'total_tax_amount': record.tax_total_amount,
    #             # 'is_advance_greater_than_tax': record.advance_amount > record.tax_total_amount,
    #             # 'note': 'Advance payment status'
    #         }
    #         rec.additional_data = additional_info

    @api.constrains('advance_amount', 'tax_total_amount')
    def _check_advance_amount(self):
        print("_check_advance_amount:::::::::::::::::::::::::")
        for record in self:
            print(record, "record::::::::::::::::::::::::::")
            print(record.advance_amount, "record.advance_amount:::::::::::::::")
            print(record.tax_total_amount, "record.tax_total_amount:::::::::::::::")
            if record.advance_amount > record.tax_total_amount:
                raise ValidationError(_("Advance amount should not be greater than tax total amount"))

    def action_conform(self):
        if self.tax_total_amount:
            self.write({'stage': 'conform'})
        else:
            raise ValidationError(_("Please enter the values in proforma percentage can not be zero"))

    def action_cancel(self):
        self.write({'stage': 'cancel'})

    def payment_register(self):
        pass

    @api.depends('advance_line_ids', 'advance_line_ids.amount')
    def _get_tax_total_amount(self):
        # pass
        for rec in self:
            total = 0
            for line in rec.advance_line_ids:
                print(line, "line::::::::::::::::::::::")
                base = line.amount
                print(base, "base::::::::::::::::::::::::::::::::::::::::::::::::::::::::")
                taxes = line.tax_ids.compute_all(base, currency=rec.currency_id)
                print(taxes, "taxes:::::::::::::::::::")
                total += taxes['total_included']
                print(total, "total::::::::::::::::::::::")
            rec.tax_total_amount = total
            print(rec.tax_total_amount, "rec.tax_total_amount::::::::::::::::::::::::::::::::")

    @api.model
    def create(self, vals):
        print("Entering the create method")
        if vals.get('proforma_invoice_seq', 'New') == 'New':
            seq = self.env['ir.sequence'].next_by_code('sale.order.advance') or '/'
            print(f"Generated sequence: {seq}")
            vals['proforma_invoice_seq'] = seq
        record = super(SaleOrderAdvance, self).create(vals)
        if record.order_id:
            record.order_id._compute_order_advance_amount()
            print("Sale Order Advance created. Recalculating total advance amount of the related sale order.")
        return record

    # def write(self, vals):
    #     res = super(SaleOrderAdvance, self).write(vals)
    #     if self.order_id:
    #         self.order_id._compute_order_advance_amount()
    #         print("Sale Order Advance updated. Recalculating total advance amount of the related sale order.")
    #     return res

    @api.model
    def write(self, vals):
        # Check if the advance_amount or tax_total_amount have changed
        for record in self:
            print(f"Processing record {record.id} with current stage: {record.stage}")

            # Track if stage needs to be changed
            stage_changed = False
            advance_amount = vals.get('advance_amount', record.advance_amount)
            tax_total_amount = vals.get('tax_total_amount', record.tax_total_amount)

            # Check if advance_amount or tax_total_amount is provided in the vals
            if 'advance_amount' in vals or 'tax_total_amount' in vals or record.advance_amount:
                print(f"Detected change in advance_amount or tax_total_amount for record {record.id}")

                # If advance_amount is equal to tax_total_amount, set the stage to 'paid'
                if advance_amount == tax_total_amount:
                    print(
                        f"advance_amount ({record.advance_amount}) equals tax_total_amount ({record.tax_total_amount})")
                    if record.stage != 'paid':
                        print(f"Stage is not 'paid'. Changing stage to 'paid'.")
                        vals['stage'] = 'paid'  # Update vals to avoid recursive write
                        stage_changed = True
                # If advance_amount is less than tax_total_amount, set the stage to 'partial'
                elif record.advance_amount < record.tax_total_amount:
                    print(f"advance_amount ({record.advance_amount}) is less than tax_total_amount ({record.tax_total_amount})")
                    if record.stage != 'partial':
                        print(f"Stage is not 'partial'. Changing stage to 'partial'.")
                        vals['stage'] = 'partial'  # Update vals to avoid recursive write
                        stage_changed = True

            # If Sale Order is related, update the Sale Order advance amount
            if record.order_id:
                print(f"Updating Sale Order advance amount for Sale Order ID: {record.order_id.id}")
                record.order_id._compute_order_advance_amount()
                print("Sale Order Advance updated. Recalculating total advance amount of the related sale order.")

            # Only write changes if necessary
            if stage_changed:
                print(f"Stage has changed for record {record.id}. Proceeding with write.")
                res = super(SaleOrderAdvance, self).write(vals)
            else:
                print(f"No stage change for record {record.id}. Proceeding with default write.")
                res = super(SaleOrderAdvance, self).write(vals)

        return res

    # def write(self, vals):
    #     # Call the super method first
    #     print("ENTER in WRITEEEEEEEEEEEEEEEEEEEEE Method ")
    #     res = super(SaleOrderAdvance, self).write(vals)
    #
    #     # Check if the advance amount is provided and if it's equal to or greater than the tax total amount
    #     for record in self:
    #         if record.advance_amount:
    #             # If advance_amount is equal to tax_total_amount, set the stage to 'paid'
    #             if record.advance_amount == record.tax_total_amount:
    #                 record.write({'stage': 'paid'})
    #             # If advance_amount is less than tax_total_amount, set the stage to 'partial'
    #             elif record.advance_amount < record.tax_total_amount:
    #                 record.write({'stage': 'partial'})
    #
    #         # If there's an associated sale order, update the total advance amount
    #         if record.order_id:
    #             record.order_id._compute_order_advance_amount()
    #             print("Sale Order Advance updated. Recalculating total advance amount of the related sale order.")
    #
    #     return res

    def unlink(self):
        orders_to_update = self.mapped('order_id')
        res = super(SaleOrderAdvance, self).unlink()
        for order in orders_to_update:
            order._compute_order_advance_amount()
            print("Sale Order Advance deleted. Recalculating total advance amount of the related sale order.")
        return res

    # @classmethod
    # def create(cls, values):
    #     if 'order_id' in values:
    #         sale_order_id = values['order_id']
    #         sale_order = cls.env['sale.order'].browse(sale_order_id)
    #         print(sale_order_id, "sale_order_id@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
    #         sale_order.advance_amount += values.get('advance_amount', 0.0)
    #         print(sale_order, "sale_order@@@@@@@@@@@@@@@@@@")
    #         print(sale_order.advance_amount, "sale_order.advance_amount!!!!!!!!!!!!!!!!!!!")
    #     return super(SaleOrderAdvanceWizard, cls).create([values])

    # @api.onchange('advance_amount')
    # def advance_amount_change(self):
    #     print("VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV")
    #     active_order_id = self.env.context.get('active_id')
    #     print(active_order_id,"active_order_id$$$$$$$$$$$$$$$$$$$$$4")
    #     if active_order_id:
    #         sale_order = self.env['sale.order'].browse(active_order_id)
    #         print(sale_order.id, "sale_order_id@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
    #         sale_order.advance_amount += self.advance_amount
    #         print(sale_order.id, "sale_order@@@@@@@@@@@@@@@@@@")
    #         print(sale_order.advance_amount, "sale_order.advance_amount!!!!!!!!!!!!!!!!!!!")

    # def create(cls, vals):
    #     if 'order_id' in vals:
    #         sale_order_id = vals['order_id']
    #         sale_order = cls.env['sale.order'].browse(sale_order_id)
    #         print(sale_order_id, "sale_order_id@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
    #         sale_order.advance_amount += vals.get('advance_amount', 0.0)
    #         print(sale_order, "sale_order@@@@@@@@@@@@@@@@@@")
    #         print(sale_order.advance_amount, "sale_order.advance_amount!!!!!!!!!!!!!!!!!!!")
    #
    #     # Call super().create() and return its result
    #     new_record = super(SaleOrderAdvanceWizard, cls).create(vals)
    #     print(new_record,"new_record!!!!!!!!!!!!!!!!!")
    #     return new_record


class AccountPaymentRegister(models.TransientModel):
    _inherit = 'account.payment.register'

    def unlink(self):
        moves = self.mapped('move_ids').filtered(lambda move: move.state == 'draft')
        if moves:
            print("Related moves are in draft state. Deleting created records.")
            self.mapped('move_ids').unlink()
        else:
            print("No related moves in draft state. Skipping deletion of created records.")
        return super(AccountPaymentRegister, self).unlink()

    @api.depends('line_ids')
    def _compute_batches(self):
        ''' Group the account.move.line linked to the wizard together.
        Lines are grouped if they share 'partner_id','account_id','currency_id' & 'partner_type' and if
        0 or 1 partner_bank_id can be determined for the group.

        Computes a list of batches, each one containing:
            * payment_values:   A dictionary of payment values.
            * moves:        An account.move recordset.
        '''
        for wizard in self:
            lines = wizard.line_ids._origin

            if len(lines.company_id.root_id) > 1:
                raise UserError(_("You can't create payments for entries belonging to different companies."))
            if not lines:
                raise UserError(
                    _("You can't open the register payment wizard without at least one receivable/payable line."))

            batches = defaultdict(lambda: {'lines': self.env['account.move.line']})
            banks_per_partner = defaultdict(lambda: {'inbound': set(), 'outbound': set()})
            for line in lines:
                batch_key = self._get_line_batch_key(line)
                vals = batches[frozendict(batch_key)]
                vals['payment_values'] = batch_key
                vals['lines'] += line
                banks_per_partner[batch_key['partner_id']]['inbound' if line.balance > 0.0 else 'outbound'].add(
                    batch_key['partner_bank_id']
                )

            partner_unique_inbound = {p for p, b in banks_per_partner.items() if len(b['inbound']) == 1}
            partner_unique_outbound = {p for p, b in banks_per_partner.items() if len(b['outbound']) == 1}

            # Compute 'payment_type'.
            batch_vals = []
            seen_keys = set()
            for i, key in enumerate(list(batches)):
                if key in seen_keys:
                    continue
                vals = batches[key]
                lines = vals['lines']
                merge = (
                        batch_key['partner_id'] in partner_unique_inbound
                        and batch_key['partner_id'] in partner_unique_outbound
                )
                if merge:
                    for other_key in list(batches)[i + 1:]:
                        if other_key in seen_keys:
                            continue
                        other_vals = batches[other_key]
                        if all(
                                other_vals['payment_values'][k] == v
                                for k, v in vals['payment_values'].items()
                                if k not in ('partner_bank_id', 'payment_type')
                        ):
                            # add the lines in this batch and mark as seen
                            lines += other_vals['lines']
                            seen_keys.add(other_key)
                balance = sum(lines.mapped('balance'))
                vals['payment_values']['payment_type'] = 'inbound' if balance > 0.0 else 'outbound'
                if merge:
                    partner_banks = banks_per_partner[batch_key['partner_id']]
                    vals['partner_bank_id'] = partner_banks[vals['payment_values']['payment_type']]
                    vals['lines'] = lines
                batch_vals.append(vals)

            wizard.batches = batch_vals
            print(
                "ENTERTERD in it :::::::::::::::::::::::::::::::::::::::::::::::::222222222222222222222222222333333333333333333333:::::::::::::::::::::::::")
            return batch_vals

    def _create_payment(self):
        print("Start creating payments")
        self.ensure_one()
        all_batches = self._compute_batches()
        print(f"All batches: {all_batches}")
        batches = []

        for batch in all_batches:
            batch_account = self._get_batch_account(batch)
            print(f"Batch account: {batch_account}")
            if self.require_partner_bank_account and not batch_account.allow_out_payment:
                print(f"Skipping batch due to bank account restrictions: {batch_account}")
                continue
            batches.append(batch)

        if not batches:
            print("No valid batches found")
            raise UserError(
                _('To record payments with %s, the recipient bank account must be manually validated. You should go on the partner bank account in order to validate it.') % self.payment_method_line_id.name)

        first_batch_result = batches[0]
        print(f"First batch result: {first_batch_result}")
        edit_mode = self.can_edit_wizard and (len(first_batch_result['lines']) == 1 or self.group_payment)
        print(f"Edit mode: {edit_mode}")
        to_process = []

        if edit_mode:
            payment_vals = self._create_payment_vals_from_wizard(first_batch_result)
            print(f"Payment values from wizard: {payment_vals}")
            to_process.append({
                'create_vals': payment_vals,
                'to_reconcile': first_batch_result['lines'],
                'batch': first_batch_result,
            })
        else:
            if not self.group_payment:
                new_batches = []
                for batch_result in batches:
                    for line in batch_result['lines']:
                        new_batches.append({
                            **batch_result,
                            'payment_values': {
                                **batch_result['payment_values'],
                                'payment_type': 'inbound' if line.balance > 0 else 'outbound'
                            },
                            'lines': [line],  # Ensure lines is a list of a single line
                        })
                print(f"New batches: {new_batches}")
                batches = new_batches

            for batch_result in batches:
                print(f"Batch result: {batch_result}")
                to_process.append({
                    'create_vals': self._create_payment_vals_from_batch(batch_result),
                    'to_reconcile': batch_result['lines'],
                    'batch': batch_result,
                })

        payments = self._init_payments(to_process, edit_mode=edit_mode)
        print(f"Initialized payments: {payments}")
        self._post_payments(to_process, edit_mode=edit_mode)
        self._reconcile_payments(to_process, edit_mode=edit_mode)
        print(f"Processed payments: {payments}")
        return payments


class AccountMove(models.Model):
    _inherit = 'account.move'

    def action_post(self):
        res = super(AccountMove, self).action_post()
        if self.state == 'posted':  # Assuming 'posted' is the 'confirmed' state
            self._action_call_clearing_advance()
        return res

    def _action_call_clearing_advance(self):
        for move in self:
            # if not move.is_invoice(include_receipts=True):
            #     raise UserError(_('You can only register payments for invoices.'))

            # Ensure the context contains the active_ids for the Account Payment Register
            ctx = dict(self._context, active_ids=move.ids, active_model=self._name)

            sale_orders = self.env['sale.order'].search([('invoice_ids', 'in', move.line_ids.mapped('move_id').ids)])
            print(f"Sale orders related to the current payment context: {sale_orders}")

            payment_creation_results = []
            for sale_order in sale_orders:
                for advance in sale_order.sale_order_advance_ids:
                    if advance.flag_for_clear_advance_in_invoice != True:
                        print(f"Processing advance: {advance}")
                        payment_date = advance.date
                        amount = advance.advance_amount
                        print(f"Amount: {amount}")

                        if amount > 0:
                            payment_register_vals = {
                                'amount': amount,
                                'payment_type': 'inbound',
                                'payment_date': payment_date,
                                'partner_type': 'customer',
                                'partner_id': sale_order.partner_id.id,
                                'currency_id': sale_order.currency_id.id,
                                'journal_id': self.env['account.journal'].search([('type', '=', 'bank')], limit=1).id,
                            }
                            # Create an instance of AccountPaymentRegister with the correct context
                            payment_register = self.env['account.payment.register'].with_context(ctx).create(
                                payment_register_vals)
                            advance.flag_for_clear_advance_in_invoice = True

                            # Call the action_create_payments method and store the result
                            result = payment_register._create_payment()
                            print(f"Payment creation result: {result}")
                            payment_creation_results.append(result)

                return payment_creation_results

    # def action_clearing_advance(self):
    #     for move in self:
    #         if not move.is_invoice(include_receipts=True):
    #             raise UserError(_('You can only register payments for invoices.'))
    #
    #         # Ensure the context contains the active_ids for the Account Payment Register
    #         ctx = dict(self._context, active_ids=move.ids, active_model=self._name)
    #
    #         sale_orders = self.env['sale.order'].search([('invoice_ids', 'in', self.line_ids.mapped('move_id').ids)])
    #         print(f"Sale orders related to the current payment context: {sale_orders}")
    #
    #         for sale_order in sale_orders:
    #             advance_amount = sale_order.advance_amount
    #             print(f"Advance amount for order {sale_order.name}: {advance_amount}")
    #             if advance_amount > 0:
    #                 payment_register = {
    #                     'amount': advance_amount,
    #                     # 'payment_date': fields.Date.today(),
    #                     'payment_type': 'inbound',
    #                     'partner_type': 'customer',
    #                     'partner_id': sale_order.partner_id.id,
    #                     'currency_id': sale_order.currency_id.id,
    #                     'journal_id': self.journal_id.id,
    #                     'payment_method_id': self.payment_method_line_id.payment_method_id.id,
    #                     'ref': sale_order.name + ' Advance Payment',
    #                     'is_reconciled': True,
    #                 }
    #
    #         return payment_register.action_clearing_advance()

#
#     def _reconcile_payments(self, to_process, edit_mode=False):
#         """ Reconcile the payments.
#
#         :param to_process:  A list of python dictionary, one for each payment to create, containing:
#                             * create_vals:  The values used for the 'create' method.
#                             * to_reconcile: The journal items to perform the reconciliation.
#                             * batch:        A python dict containing everything you want about the source journal items
#                                             to which a payment will be created (see '_get_batches').
#         :param edit_mode:   Is the wizard in edition mode.
#         """
#         domain = [
#             ('parent_state', '=', 'posted'),
#             ('account_type', 'in', self.env['account.payment']._get_valid_payment_account_types()),
#             ('reconciled', '=', False),
#         ]
#         print(domain,"domain$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$")
#         for vals in to_process:
#             payment_lines = vals['payment'].line_ids.filtered_domain(domain)
#             print()
#             lines = vals['to_reconcile']
#
#             for account in payment_lines.account_id:
#                 (payment_lines + lines)\
#                     .filtered_domain([('account_id', '=', account.id), ('reconciled', '=', False)])\
#                     .reconcile()
#
#     def _create_payments(self):
#         print("@@@@@@@@@@@@@@@@!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
#         self.ensure_one()
#
#         all_batches = self._get_batches()
#         print(all_batches,"all_batches@@@@@@@@@@@@@@@@@@!!!!!!!!!!!!!")
#         batches = []
#         print("Inistaiall batches:::",batches)
#         # Skip batches that are not valid (bank account not trusted but required)
#         for batch in all_batches:
#             print(all_batches,"all_batches:::::::::::")
#             print(batch,"batch@@@@@@@@@@@@@@@@@@@@@")
#             batch_account = self._get_batch_account(batch)
#             print(batch_account,"batch_account!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
#             if self.require_partner_bank_account and not batch_account.allow_out_payment:
#                 continue
#             batches.append(batch)
#             print("batches.append(batch):::::",batches.append(batch))
#
#         if not batches:
#             print("Not Batch::::::::::::")
#             raise UserError(_('To record payments with %s, the recipient bank account must be manually validated. You should go on the partner bank account in order to validate it.', self.payment_method_line_id.name))
#
#         first_batch_result = batches[0]
#         print(first_batch_result,"first_batch_result:::::::::::::::::::::")
#         edit_mode = self.can_edit_wizard and (len(first_batch_result['lines']) == 1 or self.group_payment)
#         print(edit_mode,"edit_mode:::::::::::::::::::::::::::")
#         to_process = []
#
#         if edit_mode:
#             payment_vals = self._create_payment_vals_from_wizard(first_batch_result)
#             to_process.append({
#                 'create_vals': payment_vals,
#                 'to_reconcile': first_batch_result['lines'],
#                 'batch': first_batch_result,
#             })
#         else:
#             # Don't group payments: Create one batch per move.
#             if not self.group_payment:
#                 new_batches = []
#                 for batch_result in batches:
#                     for line in batch_result['lines']:
#                         new_batches.append({
#                             **batch_result,
#                             'payment_values': {
#                                 **batch_result['payment_values'],
#                                 'payment_type': 'inbound' if line.balance > 0 else 'outbound'
#                             },
#                             'lines': line,
#                         })
#                 batches = new_batches
#
#             for batch_result in batches:
#                 to_process.append({
#                     'create_vals': self._create_payment_vals_from_batch(batch_result),
#                     'to_reconcile': batch_result['lines'],
#                     'batch': batch_result,
#                 })
#
#         payments = self._init_payments(to_process, edit_mode=edit_mode)
#         self._post_payments(to_process, edit_mode=edit_mode)
#         self._reconcile_payments(to_process, edit_mode=edit_mode)
#         print(payments,"payments:::::::::::::::::::::::::")
#         return payments
#
#     def action_create_payments(self):
#         print("Enter in Create Payment method")
#         payments = self._create_payments()
#         print(payments,"payments#################")
#
#         if self._context.get('dont_redirect_to_payments'):
#             print(self._context.get('dont_redirect_to_payments'),"self._context.get('dont_redirect_to_payments')::::::")
#             return True
#
#         action = {
#             'name': _('Payments'),
#             'type': 'ir.actions.act_window',
#             'res_model': 'account.payment',
#             'context': {'create': False},
#         }
#         print(action,"action:::::::")
#         if len(payments) == 1:
#             action.update({
#                 'view_mode': 'form',
#                 'res_id': payments.id,
#             })
#             print(action.update,"action.update$$$$$$$$$$$$$$$$")
#         else:
#             action.update({
#                 'view_mode': 'tree,form',
#                 'domain': [('id', 'in', payments.ids)],
#             })
#             print(action.update, "action.update$$$$$$$$$$$$$$$$elseeeeeeeeeeeeeeeeeee")
#         return action
#
#
#
#
#
