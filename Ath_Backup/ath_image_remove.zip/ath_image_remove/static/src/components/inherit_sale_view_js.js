/** @odoo-module **/

import { SaleActionHelper as BaseSaleActionHelper } from "@sale/js/sale_action_helper/sale_action_helper";
import { mount } from "@odoo/owl";
import { registry } from "@web/core/registry";

export class CustomSaleActionHelper extends BaseSaleActionHelper {
    static template = "ath_image_remove.SaleActionHelper"

        setup() {
            super.setup();
            console.log("🔥 CustomSaleActionHelper setup called");
        }

        openVideoPreview() {
            this.dialogService.add(this.constructor.dialogComponent || null, {
                url: "https://www.youtube.com/embed/N4zw-2t6spk?autoplay=1&controls=1",
            });
        }
    }

    console.log("this is calling from CustomSaleActionHelper");
    CustomSaleActionHelper.template = "ath_image_remove.SaleActionHelper";

    registry.category("view_components").add("ath_image_remove.SaleActionHelper", CustomSaleActionHelper);

    mount(CustomSaleActionHelper, {
        target: document.body,
        CustomSaleActionHelper
    });