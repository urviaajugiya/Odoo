{
    'name': 'Ath Image Remove From Sale And Expense Module',
    'version': '1.0',
    'summary': 'Image Remove',
    'description': 'Image Remove',
    'author': 'Ath Software Solutions Pvt. Ltd.',
    'depends': ['base', 'sale', 'hr_expense'],
    'data': [
        'views/sale_remove_image.xml',
        'views/expense_remove_img.xml',
        # 'views/inherit_sale_view.xml',
        # 'views/inherit_sale_view.xml'
    ],
    'assets': {
        # 'web.assets_qweb': [
        #     # 'ath_image_remove/static/src/xml/inherit_sale_view.xml'
        #     'ath_image_remove/static/src/components/inherit_sale_view.xml'
        # ],
        'web.assets_frontend': [
            # 'ath_image_remove/static/src/xml/inherit_sale_view.xml',
            # 'ath_image_remove/static/src/js/sale_action_helper/inherit_sale_view.xml',
        ],
        'web.assets_backend': [
            "sale/static/src/js/sale_action_helper/sale_action_helper.js",
            # 'ath_image_remove/static/src/components/inherit_sale_view.xml',
            'ath_image_remove/static/src/xml/inherit_sale_view.xml',
            'ath_image_remove/static/src/components/inherit_sale_view_js.js',

        ],
        "license": "OPL-1",
    }
}
