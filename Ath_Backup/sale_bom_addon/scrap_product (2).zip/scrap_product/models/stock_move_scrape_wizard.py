from odoo import models, fields, api

class StockMoveScrapeWizard(models.Model):
    _name = 'stock.move.scrape.wizard'
    _description = 'Scrape Wizard for Stock Move Lines'

    production_id = fields.Many2one('mrp.production', string='Production Order', readonly=True)
    move_line_ids = fields.One2many('stock.move.scrape.line', 'wizard_id', string='Move Lines')

    @api.model
    def default_get(self, fields_list):
        res = super().default_get(fields_list)
        active_id = self.env.context.get('active_id')
        if active_id:
            mrp = self.env['mrp.production'].browse(active_id)
            move_lines_data = []
            for move in mrp.move_raw_ids:
                for line in move.move_line_ids:
                    move_lines_data.append((0, 0, {
                        'product_id': line.product_id.id,
                        'location_id': line.location_id.id,
                        'location_dest_id': line.location_dest_id.id,
                        'scrape_qty': 0.0,
                    }))
            # res['move_line_ids'] = [(5,0,0)]
            # res['move_line_ids'] =  move_lines_data

            # for move in mrp.move_raw_ids:
            #     for line in move.move_line_ids:
            #         if line.location_id and line.location_id.usage != 'view':
            #             move_lines_data.append((0, 0, {
            #                 'product_id': line.product_id.id,
            #                 'location_id': line.location_id.id,
            #                 'location_dest_id': line.location_dest_id.id,
            #                 'scrape_qty': 0.0,
            #             }))

            res['move_line_ids'] = [(5, 0, 0)] + move_lines_data

        return res

    def action_confirm_scrape(self):
        production = self.env['mrp.production'].browse(self.env.context.get('active_id'))

        for line in self.move_line_ids:
            print('line',line)
            if line.scrape_qty > 0:
                print(f"Creating scrap for product: {line.product_id.id}, Qty: {line.scrape_qty}")
                self.env['stock.scrap'].create({
                    'product_id': line.product_id.id,
                    'scrap_qty': line.scrape_qty,
                    'production_id': production.id,
                    'location_id': line.location_id.id,
                    'origin': production.name,
                    # 'scrap_location_id':,
                    'company_id': production.company_id.id
                })
                # print(f"Scrap created: ID {scrap.id}")

        print("order placed in scrap")

        return {'type': 'ir.actions.act_window_close'}
