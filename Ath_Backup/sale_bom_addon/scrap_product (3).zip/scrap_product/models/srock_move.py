from odoo import models, fields, api
from odoo.exceptions import ValidationError


class StockMove(models.Model):
    _inherit = 'stock.move'

    scrape_qty = fields.Float('Scrape Quantity', store=True)
    total_scrap_qty = fields.Float('Total Scrape Quantity', store=True, compute='_get_total_scrap')
    wizard_id = fields.Many2one('stock.move.scrape.wizard', string='Wizard', store=True)