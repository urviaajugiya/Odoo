from odoo import models, fields, api

class ScrapMove(models.Model):
    _inherit = 'stock.move'

    wizard_id = fields.Many2one('stock.move.scrape.wizard','move_ids')
    scrap = fields.Float('Scrap Qty')

