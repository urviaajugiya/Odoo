from odoo import models, fields, api

class StockMoveScrapeWizard(models.Model):
    _name = 'stock.move.scrape.wizard'
    _description = 'Scrape Wizard for Stock Moves'

    move_ids = fields.One2many('stock.move', 'wizard_id', string='Stock')

    def action_confirm_scrape(self):
            self.ensure_one()
            return {
                'type': 'ir.actions.act_window',
                # 'name': 'Scrap Products',
                # 'res_model' : 'stock.move',
                # 'view_mode': 'form',
                # 'target': 'new',
                # 'context': {
                #     # 'default_production_id': self.id,
                #     'default_product_id': self.product_id.id,
                #     # 'default_origin': self.name,
                #     'default_location_id': self.location_src_id.id,
                #     'default_quantity': self.product_qty,
                #     # 'default_company_id': self.company_id.id,
                # }
            }
