from odoo import models, fields, api
from odoo.exceptions import ValidationError


class StockMove(models.Model):
    _inherit = 'stock.move'

    scrape_qty = fields.Float('Scrape Quantity', store=True)
    total_scrap_qty = fields.Float('Total Scrape Quantity', store=True)
    wizard_temp_id = fields.Many2one(
        'stock.move.scrape.wizard',
        string='Wizard',
        readonly=True
    )