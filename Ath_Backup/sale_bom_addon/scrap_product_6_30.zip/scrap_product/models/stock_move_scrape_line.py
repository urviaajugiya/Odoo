from odoo import models, fields, api


class StockMoveScrapeLine(models.TransientModel):
    _name = 'stock.move.scrape.line'
    _description = 'Stock Move Line for Scrape Wizard'

    wizard_id = fields.Many2one('stock.move.scrape.wizard', string='Wizard',store=True)
    product_id = fields.Many2one(
        'product.product', 'Product', required=True, readonly=False,store=True)
    location_id = fields.Many2one(
        'stock.location', 'Source Location', store=True, required=True, readonly=False)
    location_dest_id = fields.Many2one('stock.location', string='Destination Location', readonly=True,store=True)
    scrape_qty = fields.Float('Scrape Quantity',store=True)
    total_scrap_qty = fields.Float('Total Scrape Quantity',store=True,compute='_get_total_scrap')
