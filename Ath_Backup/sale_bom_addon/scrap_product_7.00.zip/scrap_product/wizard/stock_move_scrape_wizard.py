from odoo import models, fields, api
from odoo.exceptions import ValidationError


class StockMoveScrapeWizard(models.TransientModel):
    _name = 'stock.move.scrape.wizard'
    _description = 'Scrape Wizard for Stock Move Lines'

    production_id = fields.Many2one('mrp.production', string='Production Order', readonly=True)
    move_line_ids = fields.One2many('stock.move.scrape.line', 'wizard_id', string='Move Lines')
    show_scrap_button = fields.Boolean(
        string='Show Scrap Button',
        compute='_compute_show_scrap_button',
        store=False
    )

    # Button Invisible when product not validate from Transfers
    @api.depends('move_line_ids')
    def _compute_show_scrap_button(self):
        for wizard in self:
            wizard.show_scrap_button = bool(wizard.move_line_ids)

    # Data Get
    @api.model
    def default_get(self, fields_list):
        res = super().default_get(fields_list)
        active_id = self.env.context.get('active_id')

        if active_id:
            mrp = self.env['mrp.production'].browse(active_id)
            move_lines_data = []
            added_products = set()

            for move in mrp.move_raw_ids:

                for line in move.move_line_ids:

                    if line.product_id.id in added_products:
                        continue

                    added_products.add(line.product_id.id)

                    # matching_scraps = move.scrap_id.filtered(lambda rec: line.product_id == rec.product_id)

                    # print("Matching scraps:", matching_scraps.product_id)

                    # total_scrap_qty = sum(matching_scraps.mapped('scrap_qty'))
                    # print("Total scrap qty:", total_scrap_qty)

                    move_lines_data.append((0, 0, {
                         'product_id': line.product_id.id,
                        'location_id': line.location_id.id,
                        'location_dest_id': line.location_dest_id.id,
                        # 'scrap_location_id': line.move_id.scrap_location_id.id,
                        # 'scrap_location_id':line.scrap_location_id.id,
                        'scrape_qty': 0.0,
                        'scrap_stock' : line.move_id.scrap_stock

                        # 'total_scrap_qty': total_scrap_qty
                    }))

            res['move_line_ids'] = [(5, 0, 0)] + move_lines_data

        return res

    # Scrap Button
    def action_confirm_scrape(self):
        production = self.env['mrp.production'].browse(self.env.context.get('active_id'))

        for line in self.move_line_ids:
            if line.scrape_qty > 0:
                print(f"Creating scrap for product: {line.product_id.id}, Qty: {line.scrape_qty}")

                related_moves = production.move_raw_ids.filtered(lambda m: m.product_id.id == line.product_id.id)

                move = related_moves[0]

                if move.product_uom_qty < line.scrape_qty:
                    raise ValidationError(
                        f"Scrap quantity ({line.scrape_qty}) cannot be greater than available quantity ({move.product_uom_qty}) "
                        f"for product {line.product_id.display_name}."
                    )

                scrap = self.env['stock.scrap'].create({
                    'product_id': line.product_id.id,
                    'scrap_qty': line.scrape_qty,
                    'production_id': production.id,
                    'location_id': line.location_id.id,
                    # 'scrap_location_id': line.move_id.scrap_location_id.id,
                    'origin': production.name,
                    'company_id': production.company_id.id
                })

                scrap.action_validate()

                # Quantity
                for rec in scrap.production_id.move_raw_ids:
                    if rec.product_id == scrap.product_id:
                        rec.quantity = rec.quantity - scrap.scrap_qty

                # Total Scrap Quantity
                for demo in scrap.production_id.move_raw_ids:
                    matching_scraps = scrap.production_id.scrap_ids.filtered(lambda d: line.product_id == d.product_id)
                    total_scrap_qty = sum(matching_scraps.mapped('scrap_qty'))
                    if demo.product_id == scrap.product_id:
                        demo.total_scrap_qty += scrap.scrap_qty

                # for rec in scrap.production_id.move_raw_ids:
                #     if rec.product_id == scrap.product_id:
                #         rec.quantity = rec.quantity > scrap.scrap_qty

                # val = scrap.production_id.move_raw_ids.filtered(lambda m: m.product_id == scrap.product_id)
                # val.quantity -= scrap.scrap_qty
                #
                # scrap.production_id.move_raw_ids.filtered(
                #     lambda m: m.product_id == scrap.product_id).quantity -= scrap.scrap_qty

        print("Order placed in scrap")
        return {'type': 'ir.actions.act_window_close'}


