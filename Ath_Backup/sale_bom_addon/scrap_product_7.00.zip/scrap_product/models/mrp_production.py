from odoo import models, fields, api
from odoo.exceptions import ValidationError


class MrpProduction(models.Model):
    _inherit = 'mrp.production'

    # total_scrap_qty = fields.Float('Total Scrape Quantity', store=True, compute='_get_total_scrap')

    def open_scrape_wizard(self):
        return {
            'name': 'Scrape Wizard',
            'type': 'ir.actions.act_window',
            'res_model': 'stock.move.scrape.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'active_id': self.id,
            }
        }

    def button_mark_done(self):
        # print(self)

        # for line in self.move_raw_ids:
        #     for rec in self.scrap_ids:
        #         if line.product_id == rec.product_id:
        #             related_move = line.product_uom_qty - rec.scrap_qty
        #
        #             if line.quantity > related_move:
        #                 raise ValidationError("wrong quantity entered")


        # for line in self.move_raw_ids:
        #     total_scrap_qty = sum(
        #         self.scrap_ids.filtered(lambda rec: line.product_id == rec.product_id).mapped('scrap_qty'))
        #     if line.quantity > line.product_uom_qty - total_scrap_qty:
        #         raise ValidationError(
        #             f"Scrap quantity ({total_scrap_qty}) cannot be greater than available quantity "
        #             f"({line.quantity}) for product '{line.product_id.display_name}'."
        #         )
        # return super().button_mark_done()
        for line in self.move_raw_ids:
            matching_scraps = self.scrap_ids.filtered(lambda rec: line.product_id == rec.product_id)

            if not matching_scraps:
                continue

            total_scrap_qty = sum(matching_scraps.mapped('scrap_qty'))

            if line.quantity > (line.product_uom_qty - total_scrap_qty):
                raise ValidationError(
                    f"Scrap quantity ({total_scrap_qty}) cannot be greater than available quantity "
                    f"({line.quantity}) for product '{line.product_id.display_name}'."
                )

        return super().button_mark_done()