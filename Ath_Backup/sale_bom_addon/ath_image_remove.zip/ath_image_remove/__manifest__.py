{
    'name': 'Ath Image Remove From Sale And Expense Module',
    'version': '1.0',
    'summary': 'Image Remove',
    'description': 'Image Remove',
    'author': 'Ath Software Solutions Pvt. Ltd.',
    'depends': ['base', 'sale', 'hr_expense'],
    'data': [
        'views/sale_remove_image.xml',
        'views/expense_remove_img.xml',
        # 'report/inherit_sale_view.xml',
        # 'views/inherit_sale_view.xml'
    ],
    'web.assets_frontend': [
        'ath_image_remove/static/src/xml/inherit_sale_view.xml',
        'ath_image_remove/static/src/js/sale_action_helper/inherit_sale_view.xml',
    ],
    'web.assets_backend': [
        'ath_image_remove/static/src/xml/inherit_sale_view.xml',
        'ath_image_remove/static/src/js/sale_action_helper/inherit_sale_view.xml',
    ],
    'qweb': [
        'static/src/xml/inherit_sale_view.xml'
    ],
    "license": "OPL-1",
}
