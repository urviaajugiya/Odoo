# - * - coding: utf - 8
{
    "name": "Ath Contractor Management",
    "description": "",
    "summary": "",
    "version": "17.0",
    "depends": ['base','mail'],
    "data": [
        "security/contractor_security.xml",
        "security/ir.model.access.csv",
        "views/register.xml",
        "views/contractor_views.xml",
        "views/site_views.xml",
    ],
    "license": "LGPL-3",
    'installable': True,
    'application': True,
    "auto_install": True,
}
