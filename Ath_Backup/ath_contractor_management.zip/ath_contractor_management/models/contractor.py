from odoo import models, fields


class Contractor(models.Model):
    _name = 'contractor'
    _description = 'Contractor'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Contractor Name')
    addr = fields.Text(string='Contractor Address')
    note = fields.Html(string='Note')
