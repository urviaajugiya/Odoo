from odoo import models, fields


class Register(models.Model):
    _name = 'register'
    _description = 'Register'
    _inherit = ['mail.thread','mail.activity.mixin']

    name = fields.Char(string="Contractor Name")
    # note_html = fields.Html(string="Note")
    notes = fields.Html(string="Note")
    contractor_id = fields.Many2one('contractor',string="Contractor Name")
    site_id = fields.Many2one('site', string='Customer Name',domain="[('site_name', '!=', False)]")
    site_name_1 = fields.Char(
        string='Site Name',
        related='site_id.site_name',
        store=True
    )
    date = fields.Date(string="Date", default=fields.Date.today)
    currency_id = fields.Many2one(
        'res.currency', string="Currency",
        default=lambda self: self.env.company.currency_id.id
    )
    amount = fields.Monetary(string="Amount", currency_field='currency_id')
    remark = fields.Text(string="Remark")