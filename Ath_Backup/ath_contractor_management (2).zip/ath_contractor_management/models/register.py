from odoo import models, fields,api
from odoo.exceptions import ValidationError

class Register(models.Model):
    _name = 'register'
    _description = 'Register Payment'
    _inherit = ['mail.thread','mail.activity.mixin']

    name = fields.Char(string="Contractor Name")
    notes = fields.Html(string="Note")
    contractor_id = fields.Many2one('contractor',string="Contractor Name")
    customer_name = fields.Many2one('site', string='Customer Name',domain="[('site_name', '!=', False)]")
    site_name = fields.One2many(
        'site',
        'name',
        string='Site Name',
        store=True,
        domain="[('name', '=', customer_name)]"
    )

    @api.onchange('customer_name')
    def _onchange_customer_name(self):
        if self.customer_name:
            sites = self.env['site'].search([
                ('name', '=', self.customer_name.name.id)
            ])
            self.site_name = sites
        else:
            self.site_name = False

    # site_name = fields.One2many(
    #     'site','customer_id',
    #     string='Site Name',
    #     # related='customer_name.site_name',
    #     store=True
    # )
    date = fields.Date(string="Date", default=fields.Date.today)
    currency_id = fields.Many2one(
        'res.currency', string="Currency",
        default=lambda self: self.env.company.currency_id.id
    )
    amount = fields.Monetary(string="Amount", currency_field='currency_id',tracking=True)
    remarks = fields.Text(string="Remarks")

    @api.constrains('amount')
    def _check_amount_non_zero(self):
        for record in self:
            if record.amount == 0:
                raise ValidationError("Amount cannot be zero.")