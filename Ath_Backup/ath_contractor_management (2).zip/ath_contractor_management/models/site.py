from odoo import models, fields


class Site(models.Model):
    _name = 'site'
    _description = 'Site'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Many2one('register',string="Customer Name")
    site_name = fields.Char(string='Site Name')
    site_incharge = fields.Char(string='Site Incharge')

    street = fields.Char("Street")
    street2 = fields.Char("Street2")
    city = fields.Char("City")
    zip = fields.Char("ZIP")
    state_id = fields.Many2one('res.country.state', string="State")
    country_id = fields.Many2one('res.country', string="Country")