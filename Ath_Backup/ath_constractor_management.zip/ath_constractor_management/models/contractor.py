from odoo import models, fields


class Contractor(models.Model):
    _name = 'contractor'
    _description = 'Contractor'

    name = fields.Char(string='Contractor Name')
    addr = fields.Text(string='Contractor Address')
