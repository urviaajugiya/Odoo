from odoo import models, fields


class Register(models.Model):
    _name = 'register'
    _description = 'Register'

    name = fields.Char(string="Contractor Name")
    contractor_id = fields.Many2one('contractor',string="Contractor Name")
    site_id = fields.Many2one('site', string='Customer Name',domain="[('site_name', '!=', False)]")
    date = fields.Date(string="Date", default=fields.Date.today)
    currency_id = fields.Many2one(
        'res.currency', string="Currency",
        default=lambda self: self.env.company.currency_id.id
    )
    amount = fields.Monetary(string="Amount", currency_field='currency_id')
    remark = fields.Text(string="Remark")