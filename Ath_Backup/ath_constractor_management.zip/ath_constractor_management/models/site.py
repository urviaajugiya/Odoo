from odoo import models, fields


class Site(models.Model):
    _name = 'site'
    _description = 'Site'

    name = fields.Char(string="Name")
    customer_name = fields.Char(string='Customer Name')
    site_name = fields.Char(string='Site Name')
    site_address = fields.Text(string='Site Address')
    site_incharge = fields.Many2one('res.users', string='Site Incharge')
