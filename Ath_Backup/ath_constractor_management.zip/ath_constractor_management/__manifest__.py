# - * - coding: utf - 8
{
    "name": "Ath Constractor Management",
    "description": "",
    "summary": "",
    "version": "17.0",
    "depends": ['base'],
    "data": [
        "security/ir.model.access.csv",
        "views/contractor_views.xml",
        "views/site_views.xml",
        "views/register.xml"
    ],
    "license": "LGPL-3",
    'installable': True,
    'application': True,
    "auto_install": True,
}
